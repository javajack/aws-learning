const BRANCH = 'chrome';
var config = {
	"hostname": "scalr.api.appbase.io",
	"appname": "moviedb",
	"username": "pW2DT42Cw",
	"password": "a4fae72b-014d-4600-bb6e-544be036db40",
	"email":"farhan687@gmail.com",
	"url":"https://uHg3p7p70:155898a9-e597-430e-8e2b-61fd1914c0d0@scalr.api.appbase.io"
};