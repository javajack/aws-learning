var React = require('react');
var ReactDOM = require('react-dom');
var HomePage = require('./HomePage.jsx');

ReactDOM.render(<HomePage />, document.getElementById('main'));